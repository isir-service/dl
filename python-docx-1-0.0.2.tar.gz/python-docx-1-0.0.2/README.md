# python-docx-1

*python-docx-1* is a Python library for creating and updating Microsoft Word (.docx) files.

## Development 
### Install dev dependencies
```sh
pipenv shell
pipenv install --dev
```

## Documentation 
Detailed documentation can be found [here](https://python-docx.readthedocs.io/en/latest/index.html)
