
Enumerations
============

Documentation for the various enumerations used for |docx| property settings
can be found here:

.. toctree::
   :titlesonly:

   MsoColorType
   MsoThemeColorIndex
   WdAlignParagraph
   WdBuiltinStyle
   WdCellVerticalAlignment
   WdColorIndex
   WdLineSpacing
   WdOrientation
   WdRowAlignment
   WdRowHeightRule
   WdSectionStart
   WdStyleType
   WdTabAlignment
   WdTabLeader
   WdTableDirection
   WdUnderline
