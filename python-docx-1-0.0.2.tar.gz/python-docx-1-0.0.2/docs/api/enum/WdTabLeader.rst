.. _WdTabLeader:

``WD_TAB_LEADER``
=================

Specifies the character to use as the leader with formatted tabs.

----

SPACES
    Spaces. Default.

DOTS
    Dots.

DASHES
    Dashes.

LINES
    Double lines.

HEAVY
    A heavy line.

MIDDLE_DOT
    A vertically-centered dot.
